<!DOCTYPE html>
<html>
<head>
    <title>Simple Test</title>
</head>
<body>
    <h1>Simple Test Page</h1>
    <p>If you can see this, the web server is working.</p>
    <p>Current time: <?php echo date('Y-m-d H:i:s'); ?></p>
    <p>PHP version: <?php echo phpversion(); ?></p>
</body>
</html> 